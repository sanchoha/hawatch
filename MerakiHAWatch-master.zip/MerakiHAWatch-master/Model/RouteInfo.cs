﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MerakiHAWatch.Model
{
    public class RouteInfo
    {
        public string ResourceGroup { get; set; }
        public string RouteTableName { get; set; }
        public string RouteName { get; set; }
    }
}
